import json
from datetime import datetime
import boto3


s3_client=boto3.client('s3')
sqs_client=boto3.client('sqs')
destination_bucket='dehlive-sales-520147374298-us-east-1'


lambda_event = '{"version":"0","id":"6218cc71-35c7-4de6-e3dd-bc8d8a5bd6e6","detail-type":"Object Created","source":"aws.s3","account":"520147374298","time":"2024-06-09T20:43:34Z","region":"us-east-1","resources":["arn:aws:s3:::practice-bucket-safia"],"detail":{"version":"0","bucket":{"name":"practice-bucket-safia"},"object":{"key":"raw/sales/input/sales_rds_excercise_full.csv","size":111240,"etag":"f5a07b27e43f042725daec046df103c9","sequencer":"00666613F6DD58A741"},"request-id":"G5VRSTK1ZPWH1KY3","requester":"520147374298","source-ip-address":"73.6.211.151","reason":"PutObject"}}'
try :
    lambda_dict =json.loads(lambda_event)
    bucket_name = lambda_dict["detail"]["bucket"]["name"]
    bucket_key = lambda_dict["detail"]["object"]["key"]
    file_name = bucket_key.split('/')[-1]
    datecreated = datetime.now().strftime("%Y-%m-%d")
    destination_key = f"archive/sales/{datecreated}/{file_name}"
    region='us-east-1'
    aws_account='520147374298'
    queue_url = f"https://sqs.{region}.amazonaws.com/{aws_account}/deh-bootcamp"
    ##################
    #region_name = boto3.Session().region.name
    #aws_account=get_aws_account_id()
    #################
    # print(lambda_dict)
    # print(bucket_name)
    # print(bucket_key)
    # print(datecreated)
    # print(archive_key)
    s3_client.copy_object(CopySource={'Bucket': bucket_name, 'Key':bucket_key},
                          Bucket=destination_bucket, Key=destination_key)

    s3_client.delete_object(Bucket=bucket_name, Key=bucket_key)
    print(f'Copied Object from s3://{bucket_name}/{bucket_key} to s3://{destination_bucket}/{destination_key} and deleted from raw')

    sqs_client.delete_message(QueueUrl = queue_url)
except Exception as e:
    print(f'Error: {e}')
